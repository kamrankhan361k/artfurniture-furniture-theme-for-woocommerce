<?php
/**
 * Product Loop Start
 *
 * @author 		WooThemes
 * @package 	WooCommerce/Templates
 * @version     30.3.0
 */
global $wp_query, $woocommerce_loop;
$artfurniture_opt = get_option( 'artfurniture_opt' );
$shoplayout = 'sidebar';
if(isset($artfurniture_opt['shop_layout']) && $artfurniture_opt['shop_layout']!=''){
	$shoplayout = $artfurniture_opt['shop_layout'];
}
if(isset($_GET['layout']) && $_GET['layout']!=''){
	$shoplayout = $_GET['layout'];
}
$shopsidebar = 'left';
if(isset($artfurniture_opt['sidebarshop_pos']) && $artfurniture_opt['sidebarshop_pos']!=''){
	$shopsidebar = $artfurniture_opt['sidebarshop_pos'];
}
if(isset($_GET['sidebar']) && $_GET['sidebar']!=''){
	$shopsidebar = $_GET['sidebar'];
}
switch($shoplayout) {
	case 'fullwidth':
		Artfurniture_Class::artfurniture_shop_class('shop-fullwidth');
		$shopcolclass = 12;
		$shopsidebar = 'none';
		$productcols = 4;
		break;
	default:
		Artfurniture_Class::artfurniture_shop_class('shop-sidebar');
		$shopcolclass = 9;
		$productcols = 3;
}
$artfurniture_viewmode = Artfurniture_Class::artfurniture_show_view_mode();
?>
<div class="shop-products products row <?php echo esc_attr($artfurniture_viewmode);?> <?php echo esc_attr($shoplayout);?>">